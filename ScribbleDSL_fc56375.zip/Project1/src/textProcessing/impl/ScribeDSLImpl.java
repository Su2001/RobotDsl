/**
 */
package textProcessing.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import textProcessing.ScribeDSL;
import textProcessing.StopWord;
import textProcessing.Text;
import textProcessing.TextProcessingPackage;
import textProcessing.WordFrequency;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Scribe DSL</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link textProcessing.impl.ScribeDSLImpl#getStopword <em>Stopword</em>}</li>
 *   <li>{@link textProcessing.impl.ScribeDSLImpl#getText <em>Text</em>}</li>
 *   <li>{@link textProcessing.impl.ScribeDSLImpl#getWordfrequency <em>Wordfrequency</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ScribeDSLImpl extends MinimalEObjectImpl.Container implements ScribeDSL {
	/**
	 * The cached value of the '{@link #getStopword() <em>Stopword</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStopword()
	 * @generated
	 * @ordered
	 */
	protected EList<StopWord> stopword;

	/**
	 * The cached value of the '{@link #getText() <em>Text</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getText()
	 * @generated
	 * @ordered
	 */
	protected EList<Text> text;

	/**
	 * The cached value of the '{@link #getWordfrequency() <em>Wordfrequency</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWordfrequency()
	 * @generated
	 * @ordered
	 */
	protected EList<WordFrequency> wordfrequency;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ScribeDSLImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return TextProcessingPackage.Literals.SCRIBE_DSL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<StopWord> getStopword() {
		if (stopword == null) {
			stopword = new EObjectResolvingEList<StopWord>(StopWord.class, this, TextProcessingPackage.SCRIBE_DSL__STOPWORD);
		}
		return stopword;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Text> getText() {
		if (text == null) {
			text = new EObjectContainmentEList<Text>(Text.class, this, TextProcessingPackage.SCRIBE_DSL__TEXT);
		}
		return text;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<WordFrequency> getWordfrequency() {
		if (wordfrequency == null) {
			wordfrequency = new EObjectContainmentEList<WordFrequency>(WordFrequency.class, this, TextProcessingPackage.SCRIBE_DSL__WORDFREQUENCY);
		}
		return wordfrequency;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TextProcessingPackage.SCRIBE_DSL__TEXT:
				return ((InternalEList<?>)getText()).basicRemove(otherEnd, msgs);
			case TextProcessingPackage.SCRIBE_DSL__WORDFREQUENCY:
				return ((InternalEList<?>)getWordfrequency()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case TextProcessingPackage.SCRIBE_DSL__STOPWORD:
				return getStopword();
			case TextProcessingPackage.SCRIBE_DSL__TEXT:
				return getText();
			case TextProcessingPackage.SCRIBE_DSL__WORDFREQUENCY:
				return getWordfrequency();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case TextProcessingPackage.SCRIBE_DSL__STOPWORD:
				getStopword().clear();
				getStopword().addAll((Collection<? extends StopWord>)newValue);
				return;
			case TextProcessingPackage.SCRIBE_DSL__TEXT:
				getText().clear();
				getText().addAll((Collection<? extends Text>)newValue);
				return;
			case TextProcessingPackage.SCRIBE_DSL__WORDFREQUENCY:
				getWordfrequency().clear();
				getWordfrequency().addAll((Collection<? extends WordFrequency>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case TextProcessingPackage.SCRIBE_DSL__STOPWORD:
				getStopword().clear();
				return;
			case TextProcessingPackage.SCRIBE_DSL__TEXT:
				getText().clear();
				return;
			case TextProcessingPackage.SCRIBE_DSL__WORDFREQUENCY:
				getWordfrequency().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case TextProcessingPackage.SCRIBE_DSL__STOPWORD:
				return stopword != null && !stopword.isEmpty();
			case TextProcessingPackage.SCRIBE_DSL__TEXT:
				return text != null && !text.isEmpty();
			case TextProcessingPackage.SCRIBE_DSL__WORDFREQUENCY:
				return wordfrequency != null && !wordfrequency.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ScribeDSLImpl

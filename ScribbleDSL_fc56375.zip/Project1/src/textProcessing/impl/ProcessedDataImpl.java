/**
 */
package textProcessing.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import textProcessing.ProcessedData;
import textProcessing.ScribeDSL;
import textProcessing.TextProcessingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Processed Data</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link textProcessing.impl.ProcessedDataImpl#getScribedsl <em>Scribedsl</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ProcessedDataImpl extends MinimalEObjectImpl.Container implements ProcessedData {
	/**
	 * The cached value of the '{@link #getScribedsl() <em>Scribedsl</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScribedsl()
	 * @generated
	 * @ordered
	 */
	protected EList<ScribeDSL> scribedsl;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProcessedDataImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return TextProcessingPackage.Literals.PROCESSED_DATA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ScribeDSL> getScribedsl() {
		if (scribedsl == null) {
			scribedsl = new EObjectContainmentEList<ScribeDSL>(ScribeDSL.class, this, TextProcessingPackage.PROCESSED_DATA__SCRIBEDSL);
		}
		return scribedsl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TextProcessingPackage.PROCESSED_DATA__SCRIBEDSL:
				return ((InternalEList<?>)getScribedsl()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case TextProcessingPackage.PROCESSED_DATA__SCRIBEDSL:
				return getScribedsl();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case TextProcessingPackage.PROCESSED_DATA__SCRIBEDSL:
				getScribedsl().clear();
				getScribedsl().addAll((Collection<? extends ScribeDSL>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case TextProcessingPackage.PROCESSED_DATA__SCRIBEDSL:
				getScribedsl().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case TextProcessingPackage.PROCESSED_DATA__SCRIBEDSL:
				return scribedsl != null && !scribedsl.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ProcessedDataImpl

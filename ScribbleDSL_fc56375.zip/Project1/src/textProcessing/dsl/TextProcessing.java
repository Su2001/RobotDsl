package textProcessing.dsl;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.tartarus.snowball.ext.PorterStemmer;

import textProcessing.*;

public class TextProcessing {

	private static TextProcessingFactory factory = TextProcessingFactory.eINSTANCE;
	
	private static List<String> stopWords;
	
	public TextProcessing() {
		if(stopWords == null) {
			stopWords = new ArrayList<>();
			try {
			      File myObj = new File("external/EnglishStopWords.txt");
			      Scanner myReader = new Scanner(myObj);
			      while (myReader.hasNextLine()) {
			       stopWords.add(myReader.nextLine());
			      }
			      myReader.close();
			    } catch (FileNotFoundException e) {
			      System.out.println("The file not found");
			      e.printStackTrace();
			    }
		}
	}
	
	public Textinitial withData(String text) {
		return new TextBeingBuilt(factory.createScribeDSL(), text);
	}
	
	public Textinitial fromFile(String filePath) {
		String text = "";
		try {
		      File myObj = new File(filePath);
		      Scanner myReader = new Scanner(myObj);
		      while (myReader.hasNextLine()) {
		        text += " "+ myReader.nextLine();
		      }
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("The file not found");
		      e.printStackTrace();
		    }
		return new TextBeingBuilt(factory.createScribeDSL(), text);
	}
	
	public interface Textinitial{
		public TextTokenize filterStopWords();
		public TextEndOrProcessing tokenize(String delimiter);
	}
	
	public interface TextTokenize{
		public TextEndOrProcessing tokenize(String delimiter);
	}
	
	public interface TextEndOrProcessing{
		public ProcessedData build();
		public TextWordFrequency performStemming();
	}
	
	public interface TextWordFrequency{
		public TextEnd analyzeWordFrequency();
		public ProcessedData build();
	}

	
	public interface TextEnd{
		public ProcessedData build();
	}

	public static class TextBeingBuilt implements Textinitial, TextTokenize, TextEndOrProcessing, TextWordFrequency, TextEnd{
		private ScribeDSL dslBeingBuilt;
		private ProcessedData dataBeingBuilt;
		
		public TextBeingBuilt(ScribeDSL dsl, String input) {
			this.dslBeingBuilt = dsl;
			dataBeingBuilt = factory.createProcessedData();
			Text t = factory.createText();
			t.setInput(input);
			dsl.getText().add(t);
			Token token = factory.createToken();
			token.setContent(input);
			t.getTokens().add(token);
			for(String s : stopWords) {
				StopWord sw = factory.createStopWord();
				sw.setContent(s);
				dsl.getStopword().add(sw);
			}
			dataBeingBuilt.getScribedsl().add(dsl);
		}

		@Override
		public TextEnd analyzeWordFrequency() {
			HashMap<String, Integer> m = new HashMap<>();
			Text t = dslBeingBuilt.getText().get(0);
			List<WordFrequency> lw = dslBeingBuilt.getWordfrequency();
			for(Token token: t.getTokens()) {
				if(m.containsKey(token.getContent())) {
					m.replace(token.getContent(), m.get(token.getContent())+1);
				}else {
					m.put(token.getContent(), 1);
				}
			}
			for(String key: m.keySet()) {
				WordFrequency wf = factory.createWordFrequency();
				wf.setKey(key);
				wf.setValue(m.get(key));
				lw.add(wf);
			}
			
			return this;
		}

		@Override
		public ProcessedData build() {
			return dataBeingBuilt;
		}

		@Override
		public TextWordFrequency performStemming() {
			PorterStemmer stemmer = new PorterStemmer();
			Text t = dslBeingBuilt.getText().get(0);
			Text stemText = factory.createText();
			for(Token token : t.getTokens()) {
				stemmer.setCurrent(token.getContent());
				stemmer.stem();
				Token temp = factory.createToken();
				temp.setContent(stemmer.getCurrent());
				stemText.getTokens().add(temp);
			}
			dslBeingBuilt.getText().add(0, stemText);
			return this;
		}

		@Override
		public TextTokenize filterStopWords() {
			Text t = dslBeingBuilt.getText().get(0);
			String result = "";
			for(int i = 0; i < t.getTokens().size(); i ++) {
				Token token = t.getTokens().remove(0);
				String[] s = token.getContent().toLowerCase().split("\\s+");
				for(String word: s) {
					if(!stopWords.contains(word)) {
						result += word +" ";
					}
				}
				token.setContent(result);
				t.getTokens().add(token);
			}
			return this;
		} 

		@Override
		public TextEndOrProcessing tokenize(String delimiter) {
			Text t = dslBeingBuilt.getText().get(0);
			int size = t.getTokens().size();
			List<Token> lt = t.getTokens();
			for(int i = 0; i < size; i ++) {
				Token token = lt.remove(0);
				String[] s = token.getContent().split(delimiter);
				for(String word: s) {
					if(!word.isBlank()) {
						Token temp = factory.createToken();
						temp.setContent(word);
						lt.add(temp);
					}
					
				}
			}
			return this;
		}


		
	}
}

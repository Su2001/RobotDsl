package textProcessing.dsl;

import java.util.Arrays;
import java.util.List;

import textProcessing.ProcessedData;
import textProcessing.Token;
import textProcessing.WordFrequency;

public class TestDSL {
	
	public static void main (String[] args) {
		TextProcessing processor = new TextProcessing();
		String text = "This is an example text to be processed";
		ProcessedData tokenizeText = processor.withData(text)
												.tokenize("\\s+")
												.build();
		printList(tokenizeText.getScribedsl().get(0).getText().get(0).getTokens());
		ProcessedData analyseText = processor.withData(text)
				.filterStopWords()
				.tokenize("\\s+")
				.performStemming()
				.analyzeWordFrequency()
				.build();
		printList(analyseText.getScribedsl().get(0).getText().get(0).getTokens());
		ProcessedData analyseFile = processor.fromFile("test/Test1.txt")
				.filterStopWords()
				.tokenize("\\s+")
				.performStemming()
				.analyzeWordFrequency()
				.build();
		printList(analyseFile.getScribedsl().get(0).getText().get(0).getTokens());
		for(WordFrequency wf : analyseFile.getScribedsl().get(0).getWordfrequency()) {
			System.out.println("Word: " + wf.getKey() + ", Frequency: " + wf.getValue());
		}
	}
	
	public static void printList(List<Token> lt) {
		String[] s= new String[lt.size()];
		for(int i = 0; i < s.length; i++) {
			s[i] = lt.get(i).getContent();
		}
		System.out.println(Arrays.toString(s) );
	}

}

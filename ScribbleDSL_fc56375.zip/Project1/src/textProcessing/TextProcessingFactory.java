/**
 */
package textProcessing;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see textProcessing.TextProcessingPackage
 * @generated
 */
public interface TextProcessingFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	TextProcessingFactory eINSTANCE = textProcessing.impl.TextProcessingFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Scribe DSL</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scribe DSL</em>'.
	 * @generated
	 */
	ScribeDSL createScribeDSL();

	/**
	 * Returns a new object of class '<em>Text</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Text</em>'.
	 * @generated
	 */
	Text createText();

	/**
	 * Returns a new object of class '<em>Token</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Token</em>'.
	 * @generated
	 */
	Token createToken();

	/**
	 * Returns a new object of class '<em>Stop Word</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stop Word</em>'.
	 * @generated
	 */
	StopWord createStopWord();

	/**
	 * Returns a new object of class '<em>Word Frequency</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Word Frequency</em>'.
	 * @generated
	 */
	WordFrequency createWordFrequency();

	/**
	 * Returns a new object of class '<em>Processed Data</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Processed Data</em>'.
	 * @generated
	 */
	ProcessedData createProcessedData();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	TextProcessingPackage getTextProcessingPackage();

} //TextProcessingFactory

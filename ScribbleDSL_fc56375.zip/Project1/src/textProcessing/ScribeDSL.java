/**
 */
package textProcessing;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scribe DSL</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link textProcessing.ScribeDSL#getStopword <em>Stopword</em>}</li>
 *   <li>{@link textProcessing.ScribeDSL#getText <em>Text</em>}</li>
 *   <li>{@link textProcessing.ScribeDSL#getWordfrequency <em>Wordfrequency</em>}</li>
 * </ul>
 *
 * @see textProcessing.TextProcessingPackage#getScribeDSL()
 * @model
 * @generated
 */
public interface ScribeDSL extends EObject {
	/**
	 * Returns the value of the '<em><b>Stopword</b></em>' reference list.
	 * The list contents are of type {@link textProcessing.StopWord}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stopword</em>' reference list.
	 * @see textProcessing.TextProcessingPackage#getScribeDSL_Stopword()
	 * @model
	 * @generated
	 */
	EList<StopWord> getStopword();

	/**
	 * Returns the value of the '<em><b>Text</b></em>' containment reference list.
	 * The list contents are of type {@link textProcessing.Text}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Text</em>' containment reference list.
	 * @see textProcessing.TextProcessingPackage#getScribeDSL_Text()
	 * @model containment="true"
	 * @generated
	 */
	EList<Text> getText();

	/**
	 * Returns the value of the '<em><b>Wordfrequency</b></em>' containment reference list.
	 * The list contents are of type {@link textProcessing.WordFrequency}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wordfrequency</em>' containment reference list.
	 * @see textProcessing.TextProcessingPackage#getScribeDSL_Wordfrequency()
	 * @model containment="true"
	 * @generated
	 */
	EList<WordFrequency> getWordfrequency();

} // ScribeDSL

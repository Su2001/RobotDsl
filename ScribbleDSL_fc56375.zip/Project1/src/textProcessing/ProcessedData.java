/**
 */
package textProcessing;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Processed Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link textProcessing.ProcessedData#getScribedsl <em>Scribedsl</em>}</li>
 * </ul>
 *
 * @see textProcessing.TextProcessingPackage#getProcessedData()
 * @model
 * @generated
 */
public interface ProcessedData extends EObject {
	/**
	 * Returns the value of the '<em><b>Scribedsl</b></em>' containment reference list.
	 * The list contents are of type {@link textProcessing.ScribeDSL}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scribedsl</em>' containment reference list.
	 * @see textProcessing.TextProcessingPackage#getProcessedData_Scribedsl()
	 * @model containment="true"
	 * @generated
	 */
	EList<ScribeDSL> getScribedsl();

} // ProcessedData

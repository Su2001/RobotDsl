/**
 */
package textProcessing;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see textProcessing.TextProcessingFactory
 * @model kind="package"
 * @generated
 */
public interface TextProcessingPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "textProcessing";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "textProcessing";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "textProcessing";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	TextProcessingPackage eINSTANCE = textProcessing.impl.TextProcessingPackageImpl.init();

	/**
	 * The meta object id for the '{@link textProcessing.impl.ScribeDSLImpl <em>Scribe DSL</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see textProcessing.impl.ScribeDSLImpl
	 * @see textProcessing.impl.TextProcessingPackageImpl#getScribeDSL()
	 * @generated
	 */
	int SCRIBE_DSL = 0;

	/**
	 * The feature id for the '<em><b>Stopword</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCRIBE_DSL__STOPWORD = 0;

	/**
	 * The feature id for the '<em><b>Text</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCRIBE_DSL__TEXT = 1;

	/**
	 * The feature id for the '<em><b>Wordfrequency</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCRIBE_DSL__WORDFREQUENCY = 2;

	/**
	 * The number of structural features of the '<em>Scribe DSL</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCRIBE_DSL_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Scribe DSL</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCRIBE_DSL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link textProcessing.impl.TextImpl <em>Text</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see textProcessing.impl.TextImpl
	 * @see textProcessing.impl.TextProcessingPackageImpl#getText()
	 * @generated
	 */
	int TEXT = 1;

	/**
	 * The feature id for the '<em><b>Input</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT__INPUT = 0;

	/**
	 * The feature id for the '<em><b>Tokens</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT__TOKENS = 1;

	/**
	 * The number of structural features of the '<em>Text</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Text</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link textProcessing.impl.TokenImpl <em>Token</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see textProcessing.impl.TokenImpl
	 * @see textProcessing.impl.TextProcessingPackageImpl#getToken()
	 * @generated
	 */
	int TOKEN = 2;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOKEN__CONTENT = 0;

	/**
	 * The number of structural features of the '<em>Token</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOKEN_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Token</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOKEN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link textProcessing.impl.StopWordImpl <em>Stop Word</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see textProcessing.impl.StopWordImpl
	 * @see textProcessing.impl.TextProcessingPackageImpl#getStopWord()
	 * @generated
	 */
	int STOP_WORD = 3;

	/**
	 * The feature id for the '<em><b>Content</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_WORD__CONTENT = 0;

	/**
	 * The number of structural features of the '<em>Stop Word</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_WORD_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Stop Word</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_WORD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link textProcessing.impl.WordFrequencyImpl <em>Word Frequency</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see textProcessing.impl.WordFrequencyImpl
	 * @see textProcessing.impl.TextProcessingPackageImpl#getWordFrequency()
	 * @generated
	 */
	int WORD_FREQUENCY = 4;

	/**
	 * The feature id for the '<em><b>Key</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORD_FREQUENCY__KEY = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORD_FREQUENCY__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Word Frequency</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORD_FREQUENCY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Word Frequency</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WORD_FREQUENCY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link textProcessing.impl.ProcessedDataImpl <em>Processed Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see textProcessing.impl.ProcessedDataImpl
	 * @see textProcessing.impl.TextProcessingPackageImpl#getProcessedData()
	 * @generated
	 */
	int PROCESSED_DATA = 5;

	/**
	 * The feature id for the '<em><b>Scribedsl</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESSED_DATA__SCRIBEDSL = 0;

	/**
	 * The number of structural features of the '<em>Processed Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESSED_DATA_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Processed Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESSED_DATA_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link textProcessing.ScribeDSL <em>Scribe DSL</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Scribe DSL</em>'.
	 * @see textProcessing.ScribeDSL
	 * @generated
	 */
	EClass getScribeDSL();

	/**
	 * Returns the meta object for the reference list '{@link textProcessing.ScribeDSL#getStopword <em>Stopword</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Stopword</em>'.
	 * @see textProcessing.ScribeDSL#getStopword()
	 * @see #getScribeDSL()
	 * @generated
	 */
	EReference getScribeDSL_Stopword();

	/**
	 * Returns the meta object for the containment reference list '{@link textProcessing.ScribeDSL#getText <em>Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Text</em>'.
	 * @see textProcessing.ScribeDSL#getText()
	 * @see #getScribeDSL()
	 * @generated
	 */
	EReference getScribeDSL_Text();

	/**
	 * Returns the meta object for the containment reference list '{@link textProcessing.ScribeDSL#getWordfrequency <em>Wordfrequency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Wordfrequency</em>'.
	 * @see textProcessing.ScribeDSL#getWordfrequency()
	 * @see #getScribeDSL()
	 * @generated
	 */
	EReference getScribeDSL_Wordfrequency();

	/**
	 * Returns the meta object for class '{@link textProcessing.Text <em>Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Text</em>'.
	 * @see textProcessing.Text
	 * @generated
	 */
	EClass getText();

	/**
	 * Returns the meta object for the attribute '{@link textProcessing.Text#getInput <em>Input</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input</em>'.
	 * @see textProcessing.Text#getInput()
	 * @see #getText()
	 * @generated
	 */
	EAttribute getText_Input();

	/**
	 * Returns the meta object for the containment reference list '{@link textProcessing.Text#getTokens <em>Tokens</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Tokens</em>'.
	 * @see textProcessing.Text#getTokens()
	 * @see #getText()
	 * @generated
	 */
	EReference getText_Tokens();

	/**
	 * Returns the meta object for class '{@link textProcessing.Token <em>Token</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Token</em>'.
	 * @see textProcessing.Token
	 * @generated
	 */
	EClass getToken();

	/**
	 * Returns the meta object for the attribute '{@link textProcessing.Token#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Content</em>'.
	 * @see textProcessing.Token#getContent()
	 * @see #getToken()
	 * @generated
	 */
	EAttribute getToken_Content();

	/**
	 * Returns the meta object for class '{@link textProcessing.StopWord <em>Stop Word</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Stop Word</em>'.
	 * @see textProcessing.StopWord
	 * @generated
	 */
	EClass getStopWord();

	/**
	 * Returns the meta object for the attribute '{@link textProcessing.StopWord#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Content</em>'.
	 * @see textProcessing.StopWord#getContent()
	 * @see #getStopWord()
	 * @generated
	 */
	EAttribute getStopWord_Content();

	/**
	 * Returns the meta object for class '{@link textProcessing.WordFrequency <em>Word Frequency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Word Frequency</em>'.
	 * @see textProcessing.WordFrequency
	 * @generated
	 */
	EClass getWordFrequency();

	/**
	 * Returns the meta object for the attribute '{@link textProcessing.WordFrequency#getKey <em>Key</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Key</em>'.
	 * @see textProcessing.WordFrequency#getKey()
	 * @see #getWordFrequency()
	 * @generated
	 */
	EAttribute getWordFrequency_Key();

	/**
	 * Returns the meta object for the attribute '{@link textProcessing.WordFrequency#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see textProcessing.WordFrequency#getValue()
	 * @see #getWordFrequency()
	 * @generated
	 */
	EAttribute getWordFrequency_Value();

	/**
	 * Returns the meta object for class '{@link textProcessing.ProcessedData <em>Processed Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Processed Data</em>'.
	 * @see textProcessing.ProcessedData
	 * @generated
	 */
	EClass getProcessedData();

	/**
	 * Returns the meta object for the containment reference list '{@link textProcessing.ProcessedData#getScribedsl <em>Scribedsl</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Scribedsl</em>'.
	 * @see textProcessing.ProcessedData#getScribedsl()
	 * @see #getProcessedData()
	 * @generated
	 */
	EReference getProcessedData_Scribedsl();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	TextProcessingFactory getTextProcessingFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link textProcessing.impl.ScribeDSLImpl <em>Scribe DSL</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see textProcessing.impl.ScribeDSLImpl
		 * @see textProcessing.impl.TextProcessingPackageImpl#getScribeDSL()
		 * @generated
		 */
		EClass SCRIBE_DSL = eINSTANCE.getScribeDSL();

		/**
		 * The meta object literal for the '<em><b>Stopword</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCRIBE_DSL__STOPWORD = eINSTANCE.getScribeDSL_Stopword();

		/**
		 * The meta object literal for the '<em><b>Text</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCRIBE_DSL__TEXT = eINSTANCE.getScribeDSL_Text();

		/**
		 * The meta object literal for the '<em><b>Wordfrequency</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCRIBE_DSL__WORDFREQUENCY = eINSTANCE.getScribeDSL_Wordfrequency();

		/**
		 * The meta object literal for the '{@link textProcessing.impl.TextImpl <em>Text</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see textProcessing.impl.TextImpl
		 * @see textProcessing.impl.TextProcessingPackageImpl#getText()
		 * @generated
		 */
		EClass TEXT = eINSTANCE.getText();

		/**
		 * The meta object literal for the '<em><b>Input</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEXT__INPUT = eINSTANCE.getText_Input();

		/**
		 * The meta object literal for the '<em><b>Tokens</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TEXT__TOKENS = eINSTANCE.getText_Tokens();

		/**
		 * The meta object literal for the '{@link textProcessing.impl.TokenImpl <em>Token</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see textProcessing.impl.TokenImpl
		 * @see textProcessing.impl.TextProcessingPackageImpl#getToken()
		 * @generated
		 */
		EClass TOKEN = eINSTANCE.getToken();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TOKEN__CONTENT = eINSTANCE.getToken_Content();

		/**
		 * The meta object literal for the '{@link textProcessing.impl.StopWordImpl <em>Stop Word</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see textProcessing.impl.StopWordImpl
		 * @see textProcessing.impl.TextProcessingPackageImpl#getStopWord()
		 * @generated
		 */
		EClass STOP_WORD = eINSTANCE.getStopWord();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_WORD__CONTENT = eINSTANCE.getStopWord_Content();

		/**
		 * The meta object literal for the '{@link textProcessing.impl.WordFrequencyImpl <em>Word Frequency</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see textProcessing.impl.WordFrequencyImpl
		 * @see textProcessing.impl.TextProcessingPackageImpl#getWordFrequency()
		 * @generated
		 */
		EClass WORD_FREQUENCY = eINSTANCE.getWordFrequency();

		/**
		 * The meta object literal for the '<em><b>Key</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WORD_FREQUENCY__KEY = eINSTANCE.getWordFrequency_Key();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WORD_FREQUENCY__VALUE = eINSTANCE.getWordFrequency_Value();

		/**
		 * The meta object literal for the '{@link textProcessing.impl.ProcessedDataImpl <em>Processed Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see textProcessing.impl.ProcessedDataImpl
		 * @see textProcessing.impl.TextProcessingPackageImpl#getProcessedData()
		 * @generated
		 */
		EClass PROCESSED_DATA = eINSTANCE.getProcessedData();

		/**
		 * The meta object literal for the '<em><b>Scribedsl</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESSED_DATA__SCRIBEDSL = eINSTANCE.getProcessedData_Scribedsl();

	}

} //TextProcessingPackage
